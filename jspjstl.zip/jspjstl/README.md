dependency: docker-compose, npm

run: $ npm install && npm start
